 <?php
 require_once $_SERVER['DOCUMENT_ROOT'].'/header.php'; 
 ?>
<div class="block-text">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
      <h1 class="block-text-top block-text-top-pages">
        Курсы ЕГЭ по математике в Санкт-Петербурге <br>
в группах от 2 до 6 человек для 10 и 11 классов
      </h1></div></div></div></div>
<div class="preimush">
<div class="container">
  <div class="row">
 <div class="col-md-4 col-sm-6">
  <div class="preim-block">
   <img src="img/team.png" alt="Молодая команда">
   <div class="preim-block-text">
   <h2 class="h2">Lorem ipsum</h2>
   <p>dolor sit amet, consectetuer
adipiscing elit. Aenean commodo
ligula eget dolor. Aenean massa</p>
</div>
 </div></div> 
  <div class="col-md-4 col-sm-6">
  <div class="preim-block">
   <img src="img/test1.png" alt="Молодая команда">
   <div class="preim-block-text">
   <h2 class="h2">Lorem ipsum</h2>
   <p>dolor sit amet, consectetuer
adipiscing elit. Aenean commodo
ligula eget dolor. Aenean massa</p>
</div>
 </div></div> 
  <div class="col-md-4 col-sm-6">
  <div class="preim-block">
   <img src="img/test.png" alt="Молодая команда">
   <div class="preim-block-text">
   <h2 class="h2">Lorem ipsum</h2>
   <p>dolor sit amet, consectetuer
adipiscing elit. Aenean commodo
ligula eget dolor. Aenean massa</p>
</div>
 </div></div> 
  <div class="col-md-4 col-sm-6">
  <div class="preim-block">
   <img src="img/idea.png" alt="Молодая команда">
   <div class="preim-block-text">
   <h2 class="h2">Lorem ipsum</h2>
   <p>dolor sit amet, consectetuer
adipiscing elit. Aenean commodo
ligula eget dolor. Aenean massa</p>
</div>
 </div></div> 
  <div class="col-md-4 col-sm-6">
  <div class="preim-block">
   <img src="img/boy.png" alt="Молодая команда">
   <div class="preim-block-text">
   <h2 class="h2">Lorem ipsum</h2>
   <p>dolor sit amet, consectetuer
adipiscing elit. Aenean commodo
ligula eget dolor. Aenean massa</p>
</div>
 </div></div> 
  <div class="col-md-4 col-sm-6">
  <div class="preim-block">
   <img src="img/brain.png" alt="Молодая команда">
   <div class="preim-block-text">
   <h2 class="h2">Lorem ipsum</h2>
   <p>dolor sit amet, consectetuer
adipiscing elit. Aenean commodo
ligula eget dolor. Aenean massa</p>
</div>
 </div></div> 
</div></div></div>

<div class="block-text">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
      <div class="block-text-second block-text-second-pages">
        Далеко-далеко за словесными горами в стране гласных и согласных живут рыбные тексты.
Вдали от всех живут они в буквенных домах на берегу Семантика большого языкового океана. Маленький
ручеек Даль журчит по всей стране и обеспечивает ее всеми необходимыми правилами.
Эта парадигматическая страна, в которой жаренные члены предложения залетают прямо в рот.
Даже всемогущая пунктуация не имеет власти над рыбными текстами, ведущими безорфографичный
образ жизни. Однажды одна маленькая строчка рыбного текста по имени Lorem ipsum решила выйти
в большой мир грамматики. Великий Оксмокс предупреждал ее о злых запятых, диких знаках вопроса
и коварных точках с запятой, но текст не дал сбить себя с толку.
      </div>
    </div>
    </div>
  </div>
</div>
<div class="programmi">
  <div class="container">
    <div class="row">
      <h2 class="h2">Программы подготовки к ЕГЭ по математике</h2>
      <div class="col-md-12">
        <div class="programmi-spisok">
          <ul>
            <li><img src="img/line.png" alt=""><p><span>1-ый уровень:</span>даем основы алгебры и геометрии, детально разбираем темы первой части (1-12), готовим к нескольким заданиям части С. </p> </li>
            <li><img src="img/line.png" alt=""><p><span>1-ый уровень:</span>даем основы алгебры и геометрии, детально разбираем темы первой части (1-12), готовим к нескольким заданиям части С. </p> </li>
            <li><img src="img/line.png" alt=""><p><span>1-ый уровень:</span>даем основы алгебры и геометрии, детально разбираем темы первой части (1-12), готовим к нескольким заданиям части С. </p> </li>
          </ul>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="block-zahvat">
  <div class="container">
    <div class="row">


      

      <div class="col-md-12 col-sm-12 col-lg-8">
        <div class="counter">
          <h2 class="h2">До ЕГЭ осталось:</h2>
              <div id="countdown_dashboard">
        <div class="dash days_dash">

          <div class="digit">0</div>
          <div class="digit">0</div>
          </div>
        

        <div class="dash hours_dash">
          <div class="digit">0</div>
          <div class="digit">0</div>

        </div>

        <div class="dash minutes_dash">
          <div class="digit">0</div>
          <div class="digit">0</div>
        
        </div>

        <div class="dash seconds_dash">
          <div class="digit">0</div>
          <div class="digit">0</div>
        </div>
      </div>
      <div class="vrem">
        <div class="opi">
        <div class="dne"><p>Дней</p></div></div>
        <div class="opi">
        <div class="dne "><p>Часов</p></div></div>
        <div class="opi">
        <div class="dne"><p>Минут</p></div></div>
        <div class="opi">
        <div class="dne"><p>Секунд</p></div></div>
</div>
      </div>
    </div>
      <div class="col-sm-12  col-md-12 col-lg-4 ">
        <div class="block-zahvat-forma">
          <div class="block-zahvat-forma-in">
          <p>Бесплатная диагностика<br>
<span>до 26 января,</span><br>
количество мест ограничено!</p>
<form>
            
            <label class="name required">
              <input type="text" name="name" placeholder="Ваше имя">
            </label>
            
        
            <label class="phone required phone">
              <input type="text" name="phone" maxlength="15" placeholder="Номер телефона">
            </label>
         <input type="checkbox" name="checkme" id="agree" >
         <label for="agree" class="agree required">Я согласен(на) с <a onClick="popup('rabota','Блок «скидка»');">условиями обработки
персональных данных</a></label>
            <div data-name="request" class="button noselect btn" onClick="formname">Записаться</div>
          </form>
      </div>
        </div>
      </div>
    </div>
  </div>
</div>

          <script src="js/countdown.js"></script>
<script src="js/countdown_config.js"></script>
   </body>
<?php
 require_once $_SERVER['DOCUMENT_ROOT'].'/footer.php'; 
 ?>
