 <?php
 require_once $_SERVER['DOCUMENT_ROOT'].'/header.php'; 
 ?>
<div class="contakti">
    <div class="container">
    <div class="row">
      <div class="col-lg-12">
      <h1 class="block-text-top block-text-top-pages">
       Контакты
      </h1></div>
      <div class="col-md-5">
         <div class="footer-contacts">
       
        <ul>
          <li><img src="img/placeholder-contacts.png" alt="Адрес">Луначарского пр. 72к1, Санкт-Петербург</li>
          <li><img src="img/phone-call-contacts.png" alt="Телефон"><a href="#">+7(965)039-13-19</a></li>
          <li><img src="img/mail-contacts.png" alt="E-mail">info@otl-ege.ru</li>
        </ul>
      </div>
    </div>
    <div class="col-md-6 col-md-offset-1">
           <div class="contacti-metro">
          <div class="metro">
            <ul>
              <li><img src="img/metro.png" alt="Метро"> <p>м.Озерки</p></li>
               <li><img src="img/metro.png" alt="Метро"> <p>м.Проспект Просвещения</p></li>
            </ul>
          </div>
    
    
          <div class="metro">
            <ul>
              <li><img src="img/metro.png" alt="Метро"> <p>м.Академическая</p></li>
               <li><img src="img/metro.png" alt="Метро"> <p>м.Гражданский проспект</p></li>
            </ul>
          </div>
        </div>
    </div>
  </div>
    <div class="col-md-4">
      <div class="contacti-img">
        <iframe src="https://yandex.ua/map-widget/v1/?um=constructor%3A720e2e3088859cd5e9717cbaf6941ae430d6fc38143907db88af9e1bb6b8ea4e&amp;source=constructor" width="100%" height="350" frameborder="0"></iframe>
      </div>
    </div>
       <div class="col-md-4">
      <div class="contacti-img">
        <img src="img/contacti-img2.png" alt="">
      </div>
    </div>
       <div class="col-md-4">
      <div class="contacti-img">
        <img src="img/contacti-img1.png" alt="">
      </div>
    </div>
    </div>
    <div class="contakti">
    <div class="container">
    <div class="row">
      <div class="col-md-5">
         <div class="footer-contacts">
       
        <ul>
          <li><img src="img/placeholder-contacts.png" alt="Адрес">Средний проспект, д. 28, 4 этаж, Санкт-Петербург</li>
          <li><img src="img/phone-call-contacts.png" alt="Телефон"><a href="#">+7(965)039-13-19</a></li>
          <li><img src="img/mail-contacts.png" alt="E-mail">info@otl-ege.ru</li>
        </ul>
      </div>
    </div>
    <div class="col-md-6 col-md-offset-1">
           <div class="contacti-metro">
          <div class="metro">
            <ul>
              <li><img src="img/metro.png" alt="Метро"> <p>м. Василеостровская,</p></li>
          </div>
        </div>
    </div>
  </div>
   
    <div class="col-md-4">
      <div class="contacti-img">
      <iframe src="https://yandex.ua/map-widget/v1/?um=constructor%3Acf6fb6379da5f4aed8130648683b0cecda2994fc6112ed092c99aa188da54bce&amp;source=constructor" width="100%" height="350" frameborder="0"></iframe>
      </div>
      </div>
            <div class="col-md-4">
      <div class="contacti-img">
        <img src="img/1.jpg" alt="">
      </div>
    </div>
       <div class="col-md-4">
    
    </div>
    </div>
      
  </div>
   <div class="contakti">
    <div class="container">
    <div class="row">
      <div class="col-md-5">
         <div class="footer-contacts">
       
        <ul>
          <li><img src="img/placeholder-contacts.png" alt="Адрес">ул. Кораблестроителей, д.16 к.2, 4 этаж, Санкт-Петербург</li>
          <li><img src="img/phone-call-contacts.png" alt="Телефон"><a href="#">+7(965)039-13-19</a></li>
          <li><img src="img/mail-contacts.png" alt="E-mail">info@otl-ege.ru</li>
        </ul>
      </div>
    </div>
    <div class="col-md-6 col-md-offset-1">
           <div class="contacti-metro">
          <div class="metro">
            <ul>
              <li><img src="img/metro.png" alt="Метро"> <p>м.Приморская</p></li>
               
            </ul>
          </div>
        </div>
    </div>
  </div>
   
    <div class="col-md-4">
      <div class="contacti-img">
        <iframe src="https://yandex.ua/map-widget/v1/?um=constructor%3A4532a845ffcae9259c2f87cf29386c86aa756c490f229bd4bc52a8fd078384ce&amp;source=constructor" width="100%" height="350" frameborder="0"></iframe>
      </div>
      </div>
            <div class="col-md-4">
      <div class="contacti-img">
        <img src="img/3.jpg" alt="">
      </div>
    </div>
   
    </div>
      
  </div>
    </div>
</div>
 <?php
 require_once $_SERVER['DOCUMENT_ROOT'].'/footer.php'; 
 ?>