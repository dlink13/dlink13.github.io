$(document).ready(function() {
    
$('#countdown_dashboard').countDown({
					targetDate: {
						'day': 		1,
						'month': 	09,
						'year': 	2018,
						'hour': 	23,
						'min': 		59,
						'sec': 		59,	
						'utc':      true,
						},
					omitWeeks: true					
				});               
                             
});