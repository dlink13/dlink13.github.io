 <?php
 require_once $_SERVER['DOCUMENT_ROOT'].'/header.php'; 
 ?>
<div class="block-text">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
      <h1 class="block-text-top block-text-top-pages">
        Курсы ОГЭ  в Санкт-Петербурге <br>
в группах от 2 до 6 человек для 10 и 11 классов
      </h1></div></div></div></div>


<div class="block-text">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
      <div class="block-text-second block-text-second-main-pages">
        Далеко-далеко за словесными горами в стране гласных и согласных живут рыбные тексты.
Вдали от всех живут они в буквенных домах на берегу Семантика большого языкового океана. Маленький
ручеек Даль журчит по всей стране и обеспечивает ее всеми необходимыми правилами.

      </div>
    </div>
    </div>
  </div>
</div>
<div class="block-text">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
      <div class="block-text-second block-text-second-main-pages block-text-second-color">
        Далеко-далеко за словесными горами в стране гласных и согласных живут рыбные тексты.
Вдали от всех живут они в буквенных домах на берегу Семантика большого языкового океана. Маленький
ручеек Даль журчит по всей стране и обеспечивает ее всеми необходимыми правилами.
      </div>
    </div>
    </div>
  </div>
</div>
<div class="predmeti">
  <div class="container">
    <div class="row">
      <div class="col-md-2 col-sm-4 col-xs-6">
        <div class="predmet">
          <a href="kursi-oge/russkiy.php"><span class="predmet-img"><img src="../img/quill.png" alt=""></span><p>русский</p></a>
        </div>
      </div>
        <div class="col-md-2 col-sm-4 col-xs-6">
        <div class="predmet">
          <a href="kursi-oge/mathematic.php"><span class="predmet-img"><img src="../img/abacus.png" alt=""></span><p>математика</p></a>
        </div>
      </div>
        <div class="col-md-2 col-sm-4 col-xs-6">
        <div class="predmet">
          <a href="kursi-oge/geografi.php"><span class="predmet-img"><img src="../img/employees.png" alt=""></span><p>география</p></a>
        </div>
      </div>
        <div class="col-md-2 col-sm-4 col-xs-6">
        <div class="predmet">
          <a href="kursi-oge/informatika.php"><span class="predmet-img"><img src="../img/pantheon.png" alt=""></span><p>информатика</p></a>
        </div>
      </div>
        <div class="col-md-2 col-sm-4 col-xs-6">
        <div class="predmet">
          <a href="kursi-oge/biology.php"><span class="predmet-img"><img src="../img/open-book-with-text-lines.png" alt=""></span><p>биология</p></a>
        </div>
      </div>
        <div class="col-md-2 col-sm-4 col-xs-6">
        <div class="predmet">
          <a href="kursi-oge/himiya.php"><span class="predmet-img"><img src="../img/file.png" alt=""></span><p>химия</p></a>
        </div>
      </div>
       <div class="col-md-2 col-md-offset-1 col-sm-4 col-xs-6">
        <div class="predmet">
          <a href="kursi-oge/phisics.php"><span class="predmet-img"><img src="../img/quill.png" alt=""></span><p>физика</p></a>
        </div>
      </div>
        <div class="col-md-2 col-sm-4 col-xs-6">
        <div class="predmet">
          <a href="kursi-oge/english.php"><span class="predmet-img"><img src="../img/abacus.png" alt=""></span><p>английский</p></a>
        </div>
      </div>
        <div class="col-md-2 col-sm-4 col-xs-6">
        <div class="predmet">
          <a href="kursi-oge/obshestvoznanie.php"><span class="predmet-img"><img src="../img/employees.png" alt=""></span><p>обществознание</p></a>
        </div>
      </div>
        <div class="col-md-2 col-sm-4 col-xs-6">
        <div class="predmet">
          <a href="kursi-oge/hisotry.php"><span class="predmet-img"><img src="../img/pantheon.png" alt=""></span><p>история</p></a>
        </div>
      </div>
        <div class="col-md-2 col-sm-4 col-xs-6">
        <div class="predmet">
          <a href="kursi-oge/literatura.php"><span class="predmet-img"><img src="../img/open-book-with-text-lines.png" alt=""></span><p>литература</p></a>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="block-text block-text-kursi">
  <div class="container">
    <div class="row">
      <div class="col-lg-12">
      <div class="block-text-second block-text-second-pages">
        Далеко-далеко за словесными горами в стране гласных и согласных живут рыбные тексты.
Вдали от всех живут они в буквенных домах на берегу Семантика большого языкового океана. Маленький
ручеек Даль журчит по всей стране и обеспечивает ее всеми необходимыми правилами.
Эта парадигматическая страна, в которой жаренные члены предложения залетают прямо в рот.
Даже всемогущая пунктуация не имеет власти над рыбными текстами, ведущими безорфографичный
образ жизни. Однажды одна маленькая строчка рыбного текста по имени Lorem ipsum решила выйти
в большой мир грамматики. Великий Оксмокс предупреждал ее о злых запятых, диких знаках вопроса
и коварных точках с запятой, но текст не дал сбить себя с толку.
      </div>
    </div>
    </div>
  </div>
</div>

<div class="preimush">
<div class="container">
  <div class="row">
    <div class="block-text-top block-text-top-pages">
Основные принципы нашей работы </div>
 <div class="col-md-4 col-sm-6">
  <div class="preim-block">
   <img src="../img/team.png" alt="Молодая команда">
   <div class="preim-block-text">
   <h2 class="h2">Lorem ipsum</h2>
   <p>dolor sit amet, consectetuer
adipiscing elit. Aenean commodo
ligula eget dolor. Aenean massa</p>
</div>
 </div></div> 
  <div class="col-md-4 col-sm-6">
  <div class="preim-block">
   <img src="../img/test1.png" alt="Молодая команда">
   <div class="preim-block-text">
   <h2 class="h2">Lorem ipsum</h2>
   <p>dolor sit amet, consectetuer
adipiscing elit. Aenean commodo
ligula eget dolor. Aenean massa</p>
</div>
 </div></div> 
  <div class="col-md-4 col-sm-6">
  <div class="preim-block">
   <img src="../img/test.png" alt="Молодая команда">
   <div class="preim-block-text">
   <h2 class="h2">Lorem ipsum</h2>
   <p>dolor sit amet, consectetuer
adipiscing elit. Aenean commodo
ligula eget dolor. Aenean massa</p>
</div>
 </div></div> 
  <div class="col-md-4 col-sm-6">
  <div class="preim-block">
   <img src="../img/idea.png" alt="Молодая команда">
   <div class="preim-block-text">
   <h2 class="h2">Lorem ipsum</h2>
   <p>dolor sit amet, consectetuer
adipiscing elit. Aenean commodo
ligula eget dolor. Aenean massa</p>
</div>
 </div></div> 
  <div class="col-md-4 col-sm-6">
  <div class="preim-block">
   <img src="../img/boy.png" alt="Молодая команда">
   <div class="preim-block-text">
   <h2 class="h2">Lorem ipsum</h2>
   <p>dolor sit amet, consectetuer
adipiscing elit. Aenean commodo
ligula eget dolor. Aenean massa</p>
</div>
 </div></div> 
  <div class="col-md-4 col-sm-6">
  <div class="preim-block">
   <img src="../img/brain.png" alt="Молодая команда">
   <div class="preim-block-text">
   <h2 class="h2">Lorem ipsum</h2>
   <p>dolor sit amet, consectetuer
adipiscing elit. Aenean commodo
ligula eget dolor. Aenean massa</p>
</div>
 </div></div> 
</div></div></div>
<div class="counter">
  <div class="container">
    <div class="row">
      <h2 class="h2">До ОГЭ осталось:</h2>
      <div class="col-md-8 col-md-offset-2">
              <div id="countdown_dashboard">
        <div class="dash days_dash">
            
          <div class="digit">0</div>
          <div class="digit">0</div>
          </div>
        

        <div class="dash hours_dash">
          <div class="digit">0</div>
          <div class="digit">0</div>

        </div>

        <div class="dash minutes_dash">
          <div class="digit">0</div>
          <div class="digit">0</div>
        
        </div>

        <div class="dash seconds_dash">
          <div class="digit">0</div>
          <div class="digit">0</div>
        </div>
      </div>
      <div class="vrem">
        <div class="opi">
        <div class="dne"><p>Дней</p></div></div>
        <div class="opi">
        <div class="dne "><p>Часов</p></div></div>
        <div class="opi">
        <div class="dne"><p>Минут</p></div></div>
        <div class="opi">
        <div class="dne"><p>Секунд</p></div></div>
</div>
      </div>
    </div>
  </div>
</div>
<script src="../js/countdown.js"></script>
<script src="../js/countdown_config1.js"></script>
 <?php
 require_once $_SERVER['DOCUMENT_ROOT'].'/footer.php'; 
 ?>